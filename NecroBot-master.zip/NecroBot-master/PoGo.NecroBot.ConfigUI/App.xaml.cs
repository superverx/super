﻿using System.Windows;

namespace PoGo.NecroBot.ConfigUI
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {

    }
}
