Checkout: https://github.com/NecronomiconCoding/NecroBot/wiki/Todo
