﻿namespace PoGo.NecroBot.CLI.WebSocketHandler.GetCommands.Helpers
{
    class EggListWeb
    {
        public object Incubators { get; set; }
        public object UnusedEggs { get; set; }

    }
}
