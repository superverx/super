## Stop! Before you create this issue (you can delete this section when opening the issue):
1. Have you validated that your config/auth.json and config/config.json is valid JSON? Use http://jsonlint.com/ to check.
2. Have you searched to see if there are other issues for the same issue? If so, comment on that issue instead.
3. If your question is referring to how to set up or use the bot, please join our discord instead of posting an issue: https://discord.gg/VXKxNFr

### Expected Behavior


### Actual Behavior


### Your config.json
```
your config here
```

### Steps to Reproduce


### Other Information
Version:
Windows Version:
What is affected (catch, transfer, evolve, recycle, snipe, powerup/levelup, other):
